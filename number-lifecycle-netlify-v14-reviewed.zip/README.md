Number Lifecycle Dashboard V6

Deploy folder with index.html at root to Netlify Drop. No build command needed.

The dashboard has ONE graph: monthly accumulated active inventory (line on left axis), PIS activation counts (green bars on right axis), CAND cancellation counts (red bars on right axis). Data labels appear on hover and monthly values in the table. Monthly cancellation graph always counts full months; the cancellation KPI period selector is independent.

Upload your Base File and New Status Update file to replace the embedded aggregate reference dataset. No individual phone numbers are embedded. Excel imports depend on the public SheetJS CDN.

V9: The chart displays numeric values at the end of each horizontal bar for active inventory, PIS activations, and CAND cancellations.

## Third upload: monthly fees
Upload an Excel/CSV file with Number (or ND), Monthly Fee, Start Charging Month; optionally Operator and End Charging Month. One row per number. A fee repeats each month beginning with the start month, through the optional end month (inclusive). The fee report can be exported as CSV. No currency conversion is performed; use one currency per upload. This is a recurring fee schedule, not a historical invoice or proration model. The report is calculated in the browser.


## Monthly fee file format (V11)
Required columns: `Operator`, `Monthly Fees`, `Start month`. Each row is a recurring operator monthly fee beginning in its start month (inclusive). The monthly fee is **not multiplied by number inventory**; each row is one fee entry. Multiple entries per operator are summed. No individual number identifiers are required.

### Fee start-month rule (V14)
The **Start month** on each operator fee row is the first chargeable month (inclusive). Prior months have no applicable rate. When later fee records exist for the same operator, the latest effective rate applies from its own start month onward, rather than summing rates. The revenue chart and Grand Excel Report use these same effective rates.

## PowerPoint export based on V14
Download PowerPoint (.pptx) produces two overall slides, then two slides per operator: monthly accumulated active/PIS/CAND and monthly revenue. Upload Monthly Fees file first. All V14 calculations remain unchanged.

Chart review: Full-month PIS/CAND event counts are used on all monthly bars. A reconciliation note identifies the latest CAND date count separately.
